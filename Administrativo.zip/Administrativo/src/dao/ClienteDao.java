

package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Cliente;


public class ClienteDao {
    //conexão com o BD =======
    private static Connection connection = null;
    private static PreparedStatement stmt = null;
    private static ResultSet resultSet = null;
    //========================
    //DADOS DO BANCO DE DADOS
    private final String SHEMA = "cadastro";
    private final String CAMINHO = "jdbc:mysql://localhost/"+SHEMA;
    private final String USUARIO_BD= "root";
    private final String SENHA_BD = "";
    
    //QUERY's =================
    private final String CADASTRAR_CLIENTE = "INSERT INTO cliente (nome, endereco, contato, bairro, cidade, numero, cep, uf, filiacao,contato2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private final String CONSULTAR_CLIENTE_PELO_Contato = "SELECT * FROM cliente WHERE contato2 = ?";
   
    
    
    //Construtor ALt+INSERT

    public ClienteDao() throws ClassNotFoundException {
        //registrar o driver JDBC
        Class.forName ("com.mysql.jdbc.Driver");
    }
    
    
    //cadastrar Animal
    public void cadastrar_cliente(Cliente c1) throws SQLException{
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================
        
        //Preparar a Query===========
        String query = CADASTRAR_CLIENTE;
        stmt = connection.prepareStatement(query);
        stmt.setString(1, c1.getNome());
        stmt.setString(2, c1.getEndereco());
        stmt.setString(3, c1.getContato());
        stmt.setString(4, c1.getBairro());
        stmt.setString(5, c1.getCidade());
        stmt.setString(6, c1.getNumero());
        stmt.setString(7, c1.getCep());
        stmt.setString(8, c1.getUf());
        stmt.setString(9, c1.getFiliacao());
        stmt.setString(10,c1.getContato2());
        
        //execulta a query
        stmt.execute();
        System.out.println("Cadastrado com sucesso!!!");
        
        //fechar conexao
        stmt.close();
        connection.close();
        System.out.println("Fechou Conexão");       
    }
    
    //consultar animal pelo id
    public Cliente consultarClientePeloContato(String contato) throws SQLException{
        
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================
        
        //Preparar a Query===========
        String query = CONSULTAR_CLIENTE_PELO_Contato ;
        stmt = connection.prepareStatement(query);
        stmt.setString(1, contato);      
        
        //execulta a query
        resultSet = stmt.executeQuery();
        
        Cliente c1 = new Cliente();
        
        while (resultSet.next()){
           
            c1.setNome(resultSet.getString(2));
            c1.setEndereco(resultSet.getString(3));
            c1.setContato(resultSet.getString(4));           
            c1.setBairro(resultSet.getString(5));           
            c1.setCidade(resultSet.getString(6));
            c1.setNumero(resultSet.getString(7));
            c1.setCep(resultSet.getString(8));
            c1.setUf(resultSet.getString(9));
            c1.setFiliacao(resultSet.getString(10));
            c1.setContato2(resultSet.getString(11));
           // c1.setCodigo(resultSet.getInt(1));
            
            
        }
                   
        //fechar conexao
        stmt.close();
        resultSet.close();
        connection.close();
        System.out.println("Fechou Conexão");       
       
        return c1;
    }
    
 
     
    
  
   
    
}
