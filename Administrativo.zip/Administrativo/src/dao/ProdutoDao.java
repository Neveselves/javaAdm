
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Produto;

/**
 *
 * @author elves
 */
public class ProdutoDao {
      //DADOS DO BANCO DE DADOS
    private final String SHEMA = "cadastro";
    private final String CAMINHO = "jdbc:mysql://localhost/"+SHEMA;
    private final String USUARIO_BD= "root";
    private final String SENHA_BD = "";
    
    //QUERY's =================
     private final String CADASTRAR_PRODUTO = "INSERT INTO produto (valorprod, quantidade, datasaida, dataentrada, tipoprod, nomeprod) VALUES (?, ?, ?, ?, ?, ?)";
     private final String CADASTRAR_FUNCIONARIO  = "INSERT INTO funcionario (matricula,nomefunc,cargo,cargahoraria) VALUES (?, ?, ?, ?)";
     private final String CONSULTAR_PRODUTO_PELO_TIPO = "SELECT * FROM produto WHERE tipoprod  = ?";
     private final String CONSULTAR_PRODUTO_PELO_NOME = "SELECT * FROM produto WHERE nomeprod  = ?";
     private final String CONSULTAR_produto_PELO_quantidade = "SELECT * FROM produto WHERE quantidade  = ?";
     private final String DELETAR_PRODUTO_PELO_NOME = "DELETE FROM Produto WHERE nomeprod = ?  ";
     private final String ATUALIZAR_QUANTIDADE_PELO_NOME = "UPDATE produto SET quantidade = ? WHERE nomeprod = ? ";
     private final String ATUALIZAR_VALOR_PELO_NOME = "UPDATE produto SET valorprod = ? WHERE nomeprod = ? ";
    //conexão com o BD =======
        private static Connection connection = null;
        private static PreparedStatement stmt= null;
        private static ResultSet resultSet   = null;
    //========================
    
    //Construtor ALt+INSERT

    public ProdutoDao() throws ClassNotFoundException {
        //registrar o driver JDBC
        Class.forName ("com.mysql.jdbc.Driver");
    }
    
    
    
    
     public void cadastrar_produto(Produto p1) throws SQLException{
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================
        
        //Preparar a Query===========
        String query = CADASTRAR_PRODUTO;
        stmt = connection.prepareStatement(query);
        stmt.setString(1, p1.getValorProd());
        stmt.setInt(2, p1.getQuantProd());
        stmt.setString(3, p1.getDataSaida());
        stmt.setString(4, p1.getDataEntrada());
        stmt.setString(5, p1.getTipoProd());
        stmt.setString(6, p1.getNomeProd());
        
        
        //execulta a query
        stmt.execute();
        System.out.println("Cadastrado com sucesso!!!");
        
        //fechar conexao
        stmt.close();
        connection.close();
        System.out.println("Fechou Conexão");       
    }
     public ArrayList<Produto> consultarProdutoPeloTipo( String tipoProd) throws SQLException
     {          
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================        
        //Preparar a Query===========
        String query = CONSULTAR_PRODUTO_PELO_TIPO ;
        stmt = connection.prepareStatement(query);
        stmt.setString(1, tipoProd);      
        
        //execulta a query
        resultSet = stmt.executeQuery();
         ArrayList<Produto> lista1 = new ArrayList<>();
        
      
       
        while (resultSet.next()){
             Produto p1 = new Produto();
             p1.setCodigoProd(resultSet.getInt(1));
             p1.setValorProd(resultSet.getString(2));
             p1.setDataEntrada(resultSet.getString(5));
             p1.setDataSaida(resultSet.getString(4));
             p1.setQuantProd(resultSet.getInt(3));
             p1.setTipoProd(resultSet.getString(6));
             p1.setNomeProd(resultSet.getString(7));
             lista1.add(p1);
        }
                   
        //fechar conexao
        stmt.close();
        resultSet.close();
        connection.close();
        System.out.println("Fechou Conexão");       
       
        return lista1;
        
     }
     
       public Produto consultarProdutoPeloNome( String nome) throws SQLException
     {          
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================        
        //Preparar a Query===========
        String query = CONSULTAR_PRODUTO_PELO_NOME ;
        stmt = connection.prepareStatement(query);
        stmt.setString(1, nome);      
        
        //execulta a query
        resultSet = stmt.executeQuery();
        
        Produto p1 = new Produto();
      
       
        while (resultSet.next()){
             
             p1.setCodigoProd(resultSet.getInt(1));
             p1.setValorProd(resultSet.getString(2));
           //  p1.setDataEntrada(resultSet.getString(5));
           //  p1.setDataSaida(resultSet.getString(4));
             p1.setQuantProd(resultSet.getInt(3));
            // p1.setTipoProd(resultSet.getString(6));
             p1.setNomeProd(resultSet.getString(7));
            
        }
                   
        //fechar conexao
        stmt.close();
        resultSet.close();
        connection.close();
        System.out.println("Fechou Conexão");       
       
        return p1;
        
     }
       
    public Produto consultarProduto(int quantidade) throws SQLException{
        
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================
        
        //Preparar a Query===========
        String query = CONSULTAR_produto_PELO_quantidade ;
        stmt = connection.prepareStatement(query);
        stmt.setInt(1, quantidade);      
        
        //execulta a query
        resultSet = stmt.executeQuery();
        
  Produto p1 = new  Produto();
        
        while (resultSet.next()){
           
            p1.setQuantProd(resultSet.getInt(3));
            
           
            
        }
                   
        //fechar conexao
        stmt.close();
        resultSet.close();
        connection.close();
        System.out.println("Fechou Conexão");       
       
        return p1;
    }
      public void deletarProdutoPeloNome(String nome) throws SQLException{
        
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================   
        
        //Preparar a Query===========
        String query = DELETAR_PRODUTO_PELO_NOME;
        stmt = connection.prepareStatement(query);
        stmt.setString(1, nome);     
        
        //execulta a query
        stmt.execute();
        
        //fechar conexao
        stmt.close();
        connection.close();
        System.out.println("Fechou Conexão");
        
    }
       public void atulaizarquantidadePelotipo (int novaquant, String nome) throws SQLException{
        
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================   
        
        //Preparar a Query===========
        String query = ATUALIZAR_QUANTIDADE_PELO_NOME;
        stmt = connection.prepareStatement(query);
        stmt.setInt(1, novaquant);
        stmt.setString(2, nome);      
        
        //execulta a query
        stmt.executeUpdate();
        
        //fechar conexao
        stmt.close();
        connection.close();
        System.out.println("Fechou Conexão");
        
}
        public void atulaizarvalor (String novvalor, String nome) throws SQLException{
        
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================   
        
        //Preparar a Query===========
        String query = ATUALIZAR_VALOR_PELO_NOME;
        stmt = connection.prepareStatement(query);
        stmt.setString(1, novvalor);
        stmt.setString(2, nome);      
        
        //execulta a query
        stmt.executeUpdate();
        
        //fechar conexao
        stmt.close();
        connection.close();
        System.out.println("Fechou Conexão");
        
}
  
}


     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
          /*conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        
        
        //Preparar a Query===========
        String query = CONSULTAR_PRODUTO_PELO_TIPO ;
        stmt = connection.prepareStatement(query);
        //stmt.setString(1, tipoProd);      
        
        //==============================
         
        try {
           
                try (Statement statement = connection.createStatement()) {
                    ResultSet resultSet = statement.executeQuery(query);
                    
                    DefaultTableModel defaultTableModel = new DefaultTableModel();
                    defaultTableModel = (DefaultTableModel) jTable1.getModel();
                    
                    while (defaultTableModel.getRowCount() != 0) {
                        defaultTableModel.removeRow(0);
                    }
                    
                    jTable1.setModel(defaultTableModel);
                    
                    if (resultSet.first()) {
                        do {
                            defaultTableModel.addRow(new Object[]{resultSet.getInt("codigoprod"),resultSet.getString("valorprod"), resultSet.getString("quantidade"), resultSet.getString("datasaida"), resultSet.getString("dataentrada"), resultSet.getString("tipoprod")});
                        } while (resultSet.next());
                    }   }
          
        }catch (SQLException ex) {
            Logger.getLogger(Cadastro.class.getName()).log(Level.SEVERE, null, ex);
        }
         stmt.close();
        resultSet.close();
        connection.close();
        System.out.println("Fechou Conexão"); 
        return jTable1; */
       
        
    
   
          
      
      /*  
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================
        
        //Preparar a Query===========
        String query = CONSULTAR_PRODUTO_PELO_TIPO ;
        stmt = connection.prepareStatement(query);
        stmt.setString(1, tipoProd);      
        
        //execulta a query
        resultSet = stmt.executeQuery();
        
       Produto p1 = new Produto();
            
        while (resultSet.next()){
            

           
            // p1.setCodigoProd(1);
             p1.setValorProd(resultSet.getString(2));
             p1.setDataEntrada(resultSet.getString(4));
             p1.setDataSaida(resultSet.getString(3));
             p1.setQuantProd(resultSet.getString(5));
             p1.setTipoProd(resultSet.getString(6));
             
                     
        }
                   
        //fechar conexao
        stmt.close();
        resultSet.close();
        connection.close();
        System.out.println("Fechou Conexão");       
       
        return p1;*/
    
    
        

     //   String sql1 = "SELECT produto.idproduto, produto.descricao, produto.idarmazem, armazem.descricao, produto.custo, produto.idgrupo, grupo.descricao "
               // + "FROM produto, armazem, grupo "
               // + "WHERE produto.idarmazem = armazem.idarmazem AND produto.idgrupo = grupo.idgrupo";

   
    
 
     

