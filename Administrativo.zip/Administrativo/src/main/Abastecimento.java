
package main;

import dao.ProdutoDao;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import static main.teladeAtendimento.STQTabela1;
import model.Produto;



public class Abastecimento extends javax.swing.JFrame {

   
    public Abastecimento() {
        initComponents();
       
DefaultTableModel modelo = (DefaultTableModel)STQTabela.getModel();
       STQTabela.setRowSorter(new TableRowSorter(modelo));
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        jPanel1 = new javax.swing.JPanel();
        StqValor = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        StqQuantidade = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        BTIncluir = new javax.swing.JButton();
        STQApagar = new javax.swing.JButton();
        BTCancelar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        STQTabela = new javax.swing.JTable();
        jButtonV7 = new javax.swing.JButton();
        jButtonAlterarAB = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        SqtNomeProd = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        StqDataEntrada = new javax.swing.JFormattedTextField();
        SqtDataValidade = new javax.swing.JFormattedTextField();
        jButton2 = new javax.swing.JButton();
        mensagem = new javax.swing.JLabel();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Abastecimento");

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Abastecimento", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 3, 18), new java.awt.Color(255, 255, 0))); // NOI18N

        StqValor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StqValorActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("valor produto");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Quantidade:");

        StqQuantidade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StqQuantidadeActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Tipo de produto:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Data entrada:");

        BTIncluir.setBackground(new java.awt.Color(0, 153, 0));
        BTIncluir.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        BTIncluir.setText("Incluir");
        BTIncluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTIncluirActionPerformed(evt);
            }
        });

        STQApagar.setBackground(new java.awt.Color(255, 102, 0));
        STQApagar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        STQApagar.setText("Apagar");
        STQApagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                STQApagarActionPerformed(evt);
            }
        });

        BTCancelar.setBackground(new java.awt.Color(255, 0, 0));
        BTCancelar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        BTCancelar.setText("Cancelar");
        BTCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTCancelarActionPerformed(evt);
            }
        });

        STQTabela.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        STQTabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tipo _Produto", "Nome_Prod", "Valor _ Produto", "Quantidade", "Data_Entrada", "Data_Validade"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(STQTabela);

        jButtonV7.setBackground(new java.awt.Color(0, 153, 0));
        jButtonV7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButtonV7.setText("Voltar Para Tela de Atendimento");
        jButtonV7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonV7ActionPerformed(evt);
            }
        });

        jButtonAlterarAB.setBackground(new java.awt.Color(255, 102, 0));
        jButtonAlterarAB.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButtonAlterarAB.setText("Alterar quantidade");
        jButtonAlterarAB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAlterarABActionPerformed(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALIMENTÍCIO", "USO PESSOAL", "HIGIÊNICO", "LIMPEZA" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Data de validade: ");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Nome ");

        try {
            StqDataEntrada.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("## / ## / ####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        StqDataEntrada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StqDataEntradaActionPerformed(evt);
            }
        });

        try {
            SqtDataValidade.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("## / ## / ####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jButton2.setText("alterar valor");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        mensagem.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        mensagem.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButtonV7)
                        .addGap(18, 18, 18)
                        .addComponent(BTIncluir)
                        .addGap(18, 18, 18)
                        .addComponent(STQApagar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonAlterarAB)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(BTCancelar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel7)
                            .addComponent(jLabel2)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(SqtNomeProd, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
                            .addComponent(StqQuantidade, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
                            .addComponent(StqValor, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
                            .addComponent(jComboBox1, 0, 230, Short.MAX_VALUE)
                            .addComponent(StqDataEntrada)
                            .addComponent(SqtDataValidade))
                        .addGap(30, 30, 30)
                        .addComponent(mensagem, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(48, 48, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SqtNomeProd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(StqValor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(StqQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(mensagem, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(StqDataEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(SqtDataValidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(12, 12, 12)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonV7)
                    .addComponent(BTIncluir)
                    .addComponent(STQApagar)
                    .addComponent(jButtonAlterarAB)
                    .addComponent(BTCancelar)
                    .addComponent(jButton2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE))
        );

        jDesktopPane1.setLayer(jPanel1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAlterarABActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAlterarABActionPerformed
         mensagem.setText("");
         String nome = SqtNomeProd.getText();
        try {
          
         ProdutoDao pd = new ProdutoDao();
        
                 
         int quant = Integer.valueOf(StqQuantidade.getText());         
         pd.atulaizarquantidadePelotipo(quant, nome);
        
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Abastecimento.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch(NumberFormatException e){
            mensagem.setText("DIGITE SOMENTE NÚMEROS");
            
            
        }
         
         SqtNomeProd.requestFocus();
        

    }//GEN-LAST:event_jButtonAlterarABActionPerformed

    private void jButtonV7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonV7ActionPerformed


        teladeAtendimento At = new teladeAtendimento();
        At.setVisible(true);
        this.dispose();
        At.setLocationRelativeTo(At);


 
    }//GEN-LAST:event_jButtonV7ActionPerformed

    private void BTCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTCancelarActionPerformed
        SqtNomeProd.setText("");
        StqValor.setText("");
        StqQuantidade.setText("");
        StqDataEntrada.setText("");
        SqtDataValidade.setText("");
        jComboBox1.setSelectedItem("");

        SqtNomeProd.requestFocus();// volta o cursor para o campo incluir produtos
    }//GEN-LAST:event_BTCancelarActionPerformed

    private void STQApagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_STQApagarActionPerformed

      //  (( DefaultTableModel )STQTabela.getModel()).removeRow(STQTabela.getSelectedRow()); // apaga linha da tabela
        int apagar = JOptionPane.showConfirmDialog(null, "voce apagará um registro de seu banco de dados tem certeza ?", "VOLTAR",JOptionPane.OK_CANCEL_OPTION);
        if(apagar == 0 ){
        try {
            ProdutoDao pd = new ProdutoDao();
           String nome = SqtNomeProd.getText();
           pd.deletarProdutoPeloNome(nome);
           JOptionPane.showMessageDialog(null, "produto deletado de sua base");
          
            
        } catch (ClassNotFoundException | SQLException ex ) {
            Logger.getLogger(Abastecimento.class.getName()).log(Level.SEVERE, null, ex);
        }
      
        
        }
        
        
        
    }//GEN-LAST:event_STQApagarActionPerformed

    private void BTIncluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTIncluirActionPerformed
         
       
        try {   
               ProdutoDao pd = new ProdutoDao();
               Produto p1 = new Produto();
               
              
               String nome = SqtNomeProd.getText();
               String valor = StqValor.getText();
               int quant = Integer.valueOf(StqQuantidade.getText());
               String quant1 = String.valueOf(quant);
               String dataentrada = StqDataEntrada.getText();
               String datavalidade = SqtDataValidade.getText();
                String tipo = jComboBox1.getSelectedItem().toString();
              
              p1.setTipoProd(tipo);
              p1.setNomeProd(nome);
              p1.setValorProd(valor);
              p1.setQuantProd(quant);             
              p1.setDataEntrada(dataentrada);
              p1.setDataSaida(datavalidade);
              
              pd.cadastrar_produto(p1);
             
              
        DefaultTableModel inserir = (DefaultTableModel) STQTabela.getModel(); // insere linha na tabela
        inserir.addRow(new String[]{tipo,nome,valor,quant1,dataentrada,datavalidade });
        
        SqtNomeProd.setText("");
        StqValor.setText("");
        StqQuantidade.setText("");
        StqDataEntrada.setText("");
        SqtDataValidade.setText("");
        jComboBox1.setSelectedItem("");
      
       SqtNomeProd.requestFocus();// volta o cursor para o campo incluir produtos 
              
               
        } catch (ClassNotFoundException | SQLException | NumberFormatException ex) {
            Logger.getLogger(Abastecimento.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "nos campos de valor e quantidade use somente números");
            
        }
        
       
    }//GEN-LAST:event_BTIncluirActionPerformed

    private void StqQuantidadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StqQuantidadeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StqQuantidadeActionPerformed

    private void StqValorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StqValorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StqValorActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void StqDataEntradaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StqDataEntradaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StqDataEntradaActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        ProdutoDao pd = null;
        try {
            pd = new ProdutoDao();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Abastecimento.class.getName()).log(Level.SEVERE, null, ex);
        }        
        
        
         String nom = SqtNomeProd.getText();
         String valor = StqValor.getText();
        try {
            pd.atulaizarvalor(valor,nom);
        } catch (SQLException ex) {
            Logger.getLogger(Abastecimento.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Abastecimento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Abastecimento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Abastecimento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Abastecimento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Abastecimento().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JButton BTCancelar;
    public static javax.swing.JButton BTIncluir;
    public static javax.swing.JButton STQApagar;
    public static javax.swing.JTable STQTabela;
    private javax.swing.JFormattedTextField SqtDataValidade;
    public static javax.swing.JTextField SqtNomeProd;
    private javax.swing.JFormattedTextField StqDataEntrada;
    public static javax.swing.JTextField StqQuantidade;
    public static javax.swing.JTextField StqValor;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButtonAlterarAB;
    public static javax.swing.JButton jButtonV7;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel mensagem;
    // End of variables declaration//GEN-END:variables
}
