/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author elves
 */
public class Venda {
    
    private int codigoVenda;
    private String dataVenda;
    private String NomeVenda;
    private String valorVenda;
    private int quantVenda;
    private String nomecliente;
    private String celularcliente;

    public String getNomecliente() {
        return nomecliente;
    }

    public void setNomecliente(String nomecliente) {
        this.nomecliente = nomecliente;
    }

    public String getCelularcliente() {
        return celularcliente;
    }

    public void setCelularcliente(String celularcliente) {
        this.celularcliente = celularcliente;
    }
    
    
     

   

    public int getQuantVenda() {
        return quantVenda;
    }

    public void setQuantVenda(int quantVenda) {
        this.quantVenda = quantVenda;
    }

    public String getValorVenda() {
        return valorVenda;
    }

    public void setValorVenda(String valorVenda) {
        this.valorVenda = valorVenda;
    }

    public int getCodigoVenda() {
        return codigoVenda;
    }

    public void setCodigoVenda(int codigoVenda) {
        this.codigoVenda = codigoVenda;
    }

    public String getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(String dataVenda) {
        this.dataVenda = dataVenda;
    }

    public String getNomeVenda() {
        return NomeVenda;
    }

    public void setNomeVenda(String NomeVenda) {
        this.NomeVenda = NomeVenda;
    }
}
